package com.example.homework01_rgbslider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Random;
import java.lang.Object;

public class MainActivity extends AppCompatActivity {

    TextView txt_j_title;
    TextView txt_j_red;
    TextView txt_j_blue;
    TextView txt_j_green;
    TextView txt_j_err;
    Button btn_j_hex;
    Button btn_j_randcolor;
    SeekBar skbar_j_red;
    SeekBar skbar_j_blue;
    SeekBar skbar_j_green;
    EditText txtbox_j_hex;
    ConstraintLayout cl_j_app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int max = 255;

        txt_j_title = (TextView) findViewById(R.id.txt_v_title);
        txt_j_red = (TextView) findViewById(R.id.txt_v_red);
        txt_j_green = (TextView) findViewById(R.id.txt_v_green);
        txt_j_blue = (TextView) findViewById(R.id.txt_v_blue);
        txt_j_err = (TextView) findViewById(R.id.txt_v_err);
        btn_j_hex = (Button) findViewById(R.id.btn_v_hex);
        btn_j_randcolor = (Button) findViewById(R.id.btn_v_randcolor);
        skbar_j_red = (SeekBar) findViewById(R.id.skbar_v_red);
        skbar_j_green = (SeekBar) findViewById(R.id.skbar_v_green);
        skbar_j_blue = (SeekBar) findViewById(R.id.skbar_v_blue);
        txtbox_j_hex = (EditText) findViewById(R.id.txtbox_v_hex);
        cl_j_app = (ConstraintLayout) findViewById(R.id.cl_v_app);
        Random rand = new Random();

        skbar_j_red.setMax(max);
        skbar_j_red.setProgress(max);
        skbar_j_green.setMax(max);
        skbar_j_green.setProgress(max);
        skbar_j_blue.setMax(max);
        skbar_j_blue.setProgress(max);

        setGUIColors();

        skbar_j_red.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txt_j_red.setText("Red: " + String.valueOf(i));
                txt_j_err.setText("");
                cl_j_app.setBackgroundColor(Color.rgb(i, skbar_j_green.getProgress(), skbar_j_blue.getProgress()));
                checkBackgroundColor();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        skbar_j_green.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txt_j_green.setText("Green: " + String.valueOf(i));
                txt_j_err.setText("");
                cl_j_app.setBackgroundColor(Color.rgb(skbar_j_red.getProgress(), i, skbar_j_blue.getProgress()));
                checkBackgroundColor();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        skbar_j_blue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txt_j_blue.setText("Blue: " + String.valueOf(i));
                cl_j_app.setBackgroundColor(Color.rgb(skbar_j_red.getProgress(), skbar_j_green.getProgress(), i));
                txt_j_err.setText("");
                checkBackgroundColor();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btn_j_hex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (txtbox_j_hex.getText().toString().isEmpty())
                {
                    System.out.println("Hexadecimal form please!");
                    txt_j_err.setText("Error: Hexadecimal form please!");
                    txtbox_j_hex.getText().clear();
                }
                else
                {
                    checkHex(txtbox_j_hex.getText().toString());
                }
            }
        });

        btn_j_randcolor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int red = rand.nextInt(255);
                int green = rand.nextInt(255);
                int blue = rand.nextInt(255);

                skbar_j_red.setProgress(red);
                skbar_j_green.setProgress(green);
                skbar_j_blue.setProgress(blue);

                cl_j_app.setBackgroundColor(Color.rgb(skbar_j_red.getProgress(), skbar_j_green.getProgress(), skbar_j_blue.getProgress()));
                checkBackgroundColor();
            }
        });
    }

    void grabReferences()
    {
        txt_j_title = (TextView) findViewById(R.id.txt_v_title);
        txt_j_red = (TextView) findViewById(R.id.txt_v_red);
        txt_j_green = (TextView) findViewById(R.id.txt_v_green);
        txt_j_blue = (TextView) findViewById(R.id.txt_v_blue);
        txt_j_err = (TextView) findViewById(R.id.txt_v_err);
        btn_j_hex = (Button) findViewById(R.id.btn_v_hex);
        btn_j_randcolor = (Button) findViewById(R.id.btn_v_randcolor);
        skbar_j_red = (SeekBar) findViewById(R.id.skbar_v_red);
        skbar_j_green = (SeekBar) findViewById(R.id.skbar_v_green);
        skbar_j_blue = (SeekBar) findViewById(R.id.skbar_v_blue);
        txtbox_j_hex = (EditText) findViewById(R.id.txtbox_v_hex);
        cl_j_app = (ConstraintLayout) findViewById(R.id.cl_v_app);
    }

    void setGUIColors()
    {
        txt_j_err.setTextColor(Color.RED);
        btn_j_randcolor.setTextColor(Color.WHITE);
        btn_j_hex.setTextColor(Color.WHITE);
        btn_j_randcolor.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        btn_j_hex.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        txt_j_red.setTextColor(Color.BLACK);
        txt_j_green.setTextColor(Color.BLACK);
        txt_j_blue.setTextColor(Color.BLACK);
        txt_j_title.setTextColor(Color.BLACK);
        txtbox_j_hex.setTextColor(Color.BLACK);
        skbar_j_red.getProgressDrawable().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        skbar_j_green.getProgressDrawable().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        skbar_j_blue.getProgressDrawable().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        skbar_j_red.getThumb().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        skbar_j_green.getThumb().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        skbar_j_blue.getThumb().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
    }

    void checkHex(String str)
    {
        int size = 7;
        int counter = 0;
        boolean hexForm = false;
        String redHex;
        String greenHex;
        String blueHex;



        if (str.length() != size)
        {
            System.out.println("Hexadecimal form please!");
            txt_j_err.setText("Error: Hexadecimal form please!");
            txtbox_j_hex.getText().clear();
        }
        else
        {
            for (int i = 1; i < str.length(); i++)
            {
                if ((str.charAt(i) >= 48 && str.charAt(i) <= 57) || (str.charAt(i) >= 65 && str.charAt(i) <= 70))
                {
                    counter++;

//                    System.out.println("Counter= " + counter);
                    if (counter == 6 && str.charAt(0) == '#')
                    {
                        cl_j_app.setBackgroundColor(Color.parseColor(String.valueOf(txtbox_j_hex.getText())));

                        redHex = txtbox_j_hex.getText().toString().substring(1, 3);
                        greenHex = txtbox_j_hex.getText().toString().substring(3, 5);
                        blueHex = txtbox_j_hex.getText().toString().substring(5, 7);

                        checkBackgroundColor();
                        convertRGBToHex(redHex, greenHex, blueHex);

                        txt_j_err.setText("");
                        txtbox_j_hex.getText().clear();
//                        System.out.println(txtbox_j_hex.getText().toString().substring(1, 3));
                        hexForm = true;
                    }
                }
            }
            if (hexForm == false)
            {
                System.out.println("Hexadecimal form please!");
                txt_j_err.setText("Error: Hexadecimal form please!");
                txtbox_j_hex.getText().clear();
            }
        }
    }

    void convertRGBToHex(String rHex, String gHex, String bHex)
    {
        skbar_j_red.setProgress(Integer.valueOf(rHex, 16));
        skbar_j_green.setProgress(Integer.valueOf(gHex, 16));
        skbar_j_blue.setProgress(Integer.valueOf(bHex, 16));
    }

    void checkBackgroundColor()
    {
        if (skbar_j_red.getProgress() <= 125 && skbar_j_green.getProgress() <= 125 && skbar_j_blue.getProgress() <= 125)
        {
            btn_j_randcolor.setTextColor(Color.BLACK);
            btn_j_hex.setTextColor(Color.BLACK);
            btn_j_randcolor.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            btn_j_hex.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            txt_j_red.setTextColor(Color.WHITE);
            txt_j_green.setTextColor(Color.WHITE);
            txt_j_blue.setTextColor(Color.WHITE);
            txt_j_title.setTextColor(Color.WHITE);
            txtbox_j_hex.setTextColor(Color.WHITE);
            skbar_j_red.getProgressDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            skbar_j_green.getProgressDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            skbar_j_blue.getProgressDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            skbar_j_red.getThumb().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            skbar_j_green.getThumb().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            skbar_j_blue.getThumb().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        }
        else if (skbar_j_red.getProgress() >= 50 && skbar_j_green.getProgress() <= 150 && skbar_j_blue.getProgress() <= 150)
        {
            btn_j_hex.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            txt_j_err.setTextColor(Color.WHITE);
        }
        else
        {
            btn_j_randcolor.setTextColor(Color.WHITE);
            btn_j_hex.setTextColor(Color.WHITE);
            btn_j_randcolor.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            btn_j_hex.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            txt_j_red.setTextColor(Color.BLACK);
            txt_j_green.setTextColor(Color.BLACK);
            txt_j_blue.setTextColor(Color.BLACK);
            txt_j_title.setTextColor(Color.BLACK);
            txt_j_err.setTextColor(Color.RED);
            txtbox_j_hex.setTextColor(Color.BLACK);
            skbar_j_red.getProgressDrawable().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            skbar_j_green.getProgressDrawable().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            skbar_j_blue.getProgressDrawable().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            skbar_j_red.getThumb().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            skbar_j_green.getThumb().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
            skbar_j_blue.getThumb().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        }
    }
}